// Modbus config
#define ADDRESS 1
#define BAUDRATE 38400
#define PREDELAY 1750
#define POSTDELAY 1750
#define TIMEOUT 1000

// Finder 6M registers
#define REG_FREQUENCY 204
#define REG_ACTIVE_POWER 196
#define REG_APPARENT_POWER 200
#define REG_ENERGY 208

// Finder 6M read error
#define INVALID_DATA 0xFFFFFFFF
